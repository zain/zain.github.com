/* Copyright (c) 2012 Codeux Software <support at codeux dot com> */

#include <BlowfishEncryption/DH1080.h>
#include <BlowfishEncryption/Encryption.h>