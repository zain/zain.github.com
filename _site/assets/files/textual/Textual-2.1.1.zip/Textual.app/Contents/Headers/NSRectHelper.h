// Created by Satoshi Nakagawa <psychs AT limechat DOT net> <http://github.com/psychs/limechat>
// You can redistribute it and/or modify it under the new BSD license.
// Converted to ARC Support on June 08, 2012

#import "TextualApplication.h"

TEXTUAL_EXTERN NSPoint NSRectCenter(NSRect rect);
TEXTUAL_EXTERN NSRect NSRectAdjustInRect(NSRect r, NSRect bounds);
