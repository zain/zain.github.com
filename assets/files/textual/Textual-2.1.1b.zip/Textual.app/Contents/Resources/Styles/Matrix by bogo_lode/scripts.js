/* Defined in: "Textual.app -> Contents -> Resources -> JavaScript -> API -> core.js" */

// Textual.includeStyleResourceFile("example_1.css");
// Textual.includeStyleResourceFile("example_2.css");
// Textual.includeScriptResourceFile("example.js");

// Textual.viewInitiated = function(viewType, serverHash, channelHash, channelName) { app.logToConsole("[01] Hello world."); }

// Textual.newMessagePostedToView				= function(lineNumber)	{ app.logToConsole("[02] Hello world."); }
// Textual.historyIndicatorAddedToView			= function()			{ app.logToConsole("[03] Hello world."); }
// Textual.historyIndicatorRemovedFromView 		= function()			{ app.logToConsole("[04] Hello world."); }
// Textual.themeWillChange 						= function()			{ app.logToConsole("[05] Hello world."); }
// Textual.topicBarValueChanged 				= function(newTopic)	{ app.logToConsole("[06] Hello world."); }
// Textual.viewContentsBeingCleared 			= function()			{ app.logToConsole("[07] Hello world."); }
// Textual.viewFontSizeChanged					= function(bigger)		{ app.logToConsole("[08] Hello world."); }
// Textual.viewFinishedLoading 					= function()			{ app.logToConsole("[09] Hello world."); }
// Textual.viewPositionMovedToBottom			= function()			{ app.logToConsole("[10] Hello world."); }
// Textual.viewPositionMovedToHistoryIndicator 	= function()			{ app.logToConsole("[11] Hello world."); }
// Textual.viewPositionMovedToLine 				= function(lineNumber)	{ app.logToConsole("[12] Hello world."); }
// Textual.viewPositionMovedToTop				= function()			{ app.logToConsole("[13] Hello world."); }
